Name: Rahul Iyer

Movie Ticket System

HOW TO RUN THE PROGRAM:

- Ensure Pygame and Python is installed (Python Version 3.6.1 32-bit)
- Visual Studio Code Recommended to use
- On VS Code make sure to open program with all files 
    - You can click on "File" and then "Open File" to open the program's folder
-Check on the left side of the screen if all items with the program are there
- To run, you can do "Ctrl + ~" to open the terminal
- In the terminal type "python website.py"
- You can also run it by just clicking run on the top right, the method above is only if the run button does not work
- By doing all this, the program should run.
 
 Any problems, please contact me and let me know.


